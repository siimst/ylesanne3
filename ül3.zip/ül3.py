import pygame
import sys

def draw_grid(screen, square_size, rows, cols, line_color):  
    """
    Funktsioon joonistab ruudustiku ekraanile.
    
    Args:
        screen: pygame ekraan, kuhu joonistada
        square_size: ruudu külje pikkus pikslites
        rows: ridade arv
        cols: veergude arv
        line_color: ruutude joone värv
    """
    for i in range(rows):  
        for j in range(cols):  
            pygame.draw.rect(screen, line_color, pygame.Rect(j * square_size, i * square_size, square_size, square_size), 1)  

def main(square_size, rows, cols, line_color):  
    pygame.init()  

    # Määrame ekraani suuruse
    screen = pygame.display.set_mode((640, 480))

    running = True  # Muutuja, mis määrab, kas mäng jookseb või mitte
    while running:  # Põhitsükkel
        for event in pygame.event.get():  # Käime läbi kõik sündmused
            if event.type == pygame.QUIT:  # Kui sündmus on mängu sulgemine
                running = False  # Muudame muutuja running väärtuseks False, et peatada põhitsükkel

        screen.fill((0, 255, 0))  # Täidame ekraani rohelise värviga
        draw_grid(screen, square_size, rows, cols, line_color)  # Joonistame ruudustiku
        pygame.display.flip()  # Uuendame ekraani

    pygame.quit()  # Lõpetame pygame'i kasutamise
    sys.exit()  # Lõpetame süsteemi

if __name__ == "__main__":
    # Parameetritega saab määrata ruudu suuruse, ridade ja veergude arvu ning joone värvi
    main(20, 24, 32, (255, 0, 0))  # Näiteks: ruudu suurus = 20 pikslit, read = 24, veerud = 32, joone värv punane
